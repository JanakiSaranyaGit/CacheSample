package com.landg.test.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.web.context.HttpRequestResponseHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import com.landg.test.providers.HttpRequestResponseContext;

/**
 * Servlet Filter implementation class HttpRequestResponseContextFilter
 */
@WebFilter("/HttpRequestResponseContextFilter")
public class HttpRequestResponseContextFilter extends OncePerRequestFilter {

	/**
	 * Default constructor.
	 */
	public HttpRequestResponseContextFilter() {
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request,
			HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {
		
		System.out.println("HttpRequestResponseContextFilter doFilterInternal");
		HttpRequestResponseHolder holder = new HttpRequestResponseHolder(
				request, response);
		HttpRequestResponseContext.set(holder);
		System.out.println("HttpRequestResponseContext.get()"+HttpRequestResponseContext.get().getRequest().getRequestURL().toString());
		chain.doFilter(request, response);

	}

}
