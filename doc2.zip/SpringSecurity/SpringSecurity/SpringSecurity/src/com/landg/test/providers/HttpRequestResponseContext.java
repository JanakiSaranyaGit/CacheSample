package com.landg.test.providers;

import org.springframework.security.web.context.HttpRequestResponseHolder;

public class HttpRequestResponseContext {
    private static final ThreadLocal<HttpRequestResponseHolder> REQUEST_RESPONSE = new ThreadLocal<HttpRequestResponseHolder>();

    public static HttpRequestResponseHolder get() {
        return REQUEST_RESPONSE.get();
    }

    public static void set(HttpRequestResponseHolder holder) {
        REQUEST_RESPONSE.set(holder);
    }

    public static void clean() {
        REQUEST_RESPONSE.remove();
    }

}
