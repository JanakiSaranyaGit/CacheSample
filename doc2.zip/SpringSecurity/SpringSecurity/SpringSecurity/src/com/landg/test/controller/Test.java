package com.landg.test.controller;

import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;

import com.landg.test.filter.ADSAuthenticationFilter;

public class Test {
	public static void main(String ar[])
	{
		AbstractAuthenticationProcessingFilter filter=new ADSAuthenticationFilter();
		System.out.println("filter "+filter.getClass());
	}
}
