package com.landg.test.controller;

import java.security.Principal;

import org.springframework.security.web.context.HttpRequestResponseHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.landg.test.providers.HttpRequestResponseContext;

@Controller
public class TestController {

	@RequestMapping(value="/welcome*", method = RequestMethod.GET)   
	 public String executeSecurity(ModelMap model, Principal principal ) {   
	    
		HttpRequestResponseHolder holder= HttpRequestResponseContext.get();
		System.out.println("request url"+holder.getRequest().getRequestURL());
	  return "welcomeADS";   
	    
	 }   
	
 
	    
	 @RequestMapping(value="/login", method = RequestMethod.GET)   
	 public String login(ModelMap model) {   
	    
	  return "login";   
	    
	 }   
	 @RequestMapping(value="/fail2login", method = RequestMethod.GET)   
	 public String loginerror(ModelMap model) {   
	    
	  model.addAttribute("error", "true");   
	  return "login";   
	    
	 }   
	/*@RequestMapping(value = {"/TEST"})
	public ModelAndView loginPage() {

		ModelAndView model = new ModelAndView();
		model.setViewName("LoginADS");
		return model;

	}

	@RequestMapping(value = "/welcome**")
	public ModelAndView welcomePage() {

		ModelAndView model = new ModelAndView();
		model.setViewName("welcomeADS");

		return model;

	}*/

}
