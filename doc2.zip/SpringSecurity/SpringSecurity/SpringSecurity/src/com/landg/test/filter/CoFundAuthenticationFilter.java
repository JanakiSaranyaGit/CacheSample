package com.landg.test.filter;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;

public class CoFundAuthenticationFilter  extends
AbstractAuthenticationProcessingFilter  {
	
	
	public CoFundAuthenticationFilter() {
		super("/j_CoFund_security_check");
		// TODO Auto-generated constructor stub
	}
	public CoFundAuthenticationFilter(String defaultFilterProcessesUrl) {
		super("/j_CoFund_security_check");
		// TODO Auto-generated constructor stub
	}

	@Override
	public Authentication attemptAuthentication(HttpServletRequest arg0,
			HttpServletResponse arg1) throws AuthenticationException,
			IOException, ServletException {
		System.out.println("�ntering CoFundAuthenticationFilter ");
		return null;
	}
}
