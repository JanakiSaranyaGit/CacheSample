package com.landg.test.providers;

import java.util.Map;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.context.HttpRequestResponseHolder;

public class DelegateAuthenticationProvider implements AuthenticationProvider{
	
	private Map<String,AuthenticationProvider> delegateList;


	public Map<String, AuthenticationProvider> getDelegateList() {
		return delegateList;
	}

	public void setDelegateList(Map<String, AuthenticationProvider> delegateList) {
		this.delegateList = delegateList;
	}

	@Override
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {
		System.out.println("Entering DelegateAuthenticationProvider authenticate");
		HttpRequestResponseHolder holder= HttpRequestResponseContext.get();
		System.out.println("Next "+holder.getRequest().getRequestURL());
		
		AuthenticationProvider delegateTo = delegateList.get("portal");
        return delegateTo.authenticate(authentication);

	}

	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		System.out.println("Entering DelegateAuthenticationProvider supports");
		return true;
	}

}
