package com.landg.bpa.services.movements.bulkmovements;

import java.util.List;
import java.util.Locale;

import javax.persistence.Column;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import com.landg.bpa.common.constants.BPAConstants;
import com.landg.bpa.services.iabulkupload.entities.AbstractBaseFileSource;
import com.landg.bpa.types.BPAEntityKey;

public class BulkMovementsFileSource extends AbstractBaseFileSource
{

    // file columns
    private String externalRefNo;
    private String externalRefNo2;
    private String surname;
    private String initials;
    private String currentSex;
    private String nationalInsuranceNumber;
    private String birthDate;
    private String spouseExternalRefNo;
    private String spouseExternalRefNo2;
    private String spouseSex;
    private String spouseDOB;
    private String dateofMovement;
    private String movementType;
    private String movementTypeUntranslated;
    private String arrangementName;
    private String dependantType;
    private String firstName;
    private String dependentSurname;
    private String marriageDate;
    private String schemeNumber;
    

    // for internal use 
    private byte[] arrgId;
    private String annuitantType;
   
    private String forename;
   
    private byte[] stringId;

    private String firstInitial;
    private String secondInitial;
    private String thirdInitial;
    private String autoAuthSpouse;
    private String firstForename;
    private String secondForename;
    private String thirdForename;

    // for internal use 
    private List<BPAEntityKey> reinusredAnnuityIds;

    public String getExternalRefNo()
    {
        return externalRefNo;
    }

    public void setExternalRefNo(String externalRefNo)
    {
        this.externalRefNo = externalRefNo;
    }

    public String getExternalRefNo2()
    {
        return externalRefNo2;
    }

    public void setExternalRefNo2(String externalRefNo2)
    {
        this.externalRefNo2 = externalRefNo2;
    }

    public String getSpouseExternalRefNo()
    {
        return spouseExternalRefNo;
    }

    public void setSpouseExternalRefNo(String spouseExternalRefNo)
    {
        this.spouseExternalRefNo = spouseExternalRefNo;
    }

    public String getSpouseExternalRefNo2()
    {
        return spouseExternalRefNo2;
    }

    public void setSpouseExternalRefNo2(String spouseExternalRefNo2)
    {
        this.spouseExternalRefNo2 = spouseExternalRefNo2;
    }

    public String getSpouseSex()
    {
        return spouseSex;
    }

    public void setSpouseSex(String spouseSex)
    {
        this.spouseSex = spouseSex;
    }

    public String getSpouseDOB()
    {
        return spouseDOB;
    }

    public void setSpouseDOB(String spouseDOB)
    {
        this.spouseDOB = spouseDOB;
    }

    public String getDateofMovement()
    {
        return dateofMovement;
    }

    public void setDateofMovement(String dateofMovement)
    {
        this.dateofMovement = dateofMovement;
    }

    public String getMovementType()
    {
        return movementType;
    }

    public void setMovementType(String movementType)
    {
        this.movementType = movementType;
    }

    public String getArrangementName()
    {
        return arrangementName;
    }

    public void setArrangementName(String arrangementName)
    {
        this.arrangementName = arrangementName;
    }

    public List<BPAEntityKey> getReinusredAnnuityIds()
    {
        return reinusredAnnuityIds;
    }

    public void setReinusredAnnuityIds(List<BPAEntityKey> reinusredAnnuityIds)
    {
        this.reinusredAnnuityIds = reinusredAnnuityIds;
    }

    public byte[] getArrgId()
    {
        return ArrayUtils.clone(arrgId);
    }

    public void setArrgId(byte[] arrgId)
    {
        this.arrgId = ArrayUtils.clone(arrgId);
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getSurname()
    {
        return surname;
    }

    public void setSurname(String surname)
    {
        this.surname = surname;
    }

    public String getDependantType()
    {
        return dependantType;
    }

    public void setDependantType(String dependantType)
    {
        this.dependantType = dependantType;
    }

    public String getMarriageDate()
    {
        return marriageDate;
    }

    public void setMarriageDate(String marriageDate)
    {
        this.marriageDate = marriageDate;
    }

    public String getAnnuitantType()
    {
        return annuitantType;
    }

    public void setAnnuitantType(String annuitantType)
    {
        this.annuitantType = annuitantType;
    }

    /**
     * @return Returns the movementTypeUntranslated.
     */
    public String getMovementTypeUntranslated()
    {
        return movementTypeUntranslated;
    }

    /**
     * @param movementTypeUntranslated The movementTypeUntranslated to set.
     */
    public void setMovementTypeUntranslated(String movementTypeUntranslated)
    {
        this.movementTypeUntranslated = movementTypeUntranslated;
    }

    public String getDependentSurname()
    {
        return dependentSurname;
    }

    public void setDependentSurname(String dependentSurname)
    {
        this.dependentSurname = dependentSurname;
    }

    public String getInitials()
    {
        return initials;
    }

    public void setInitials(String initials)
    {
        this.initials = initials;
    }

    public String getForename()
    {
        return forename;
    }

    public void setForenames(String forename)
    {
        this.forename = forename;
    }

    public String getBirthDate()
    {
        return birthDate;
    }

    public void setBirthDate(String birthDate)
    {
        this.birthDate = birthDate;
    }

    public String getCurrentSex()
    {
        return currentSex;
    }

    public void setCurrentSex(String currentSex)
    {
        this.currentSex = currentSex;
    }

    public String getNationalInsuranceNumber()
    {
        return nationalInsuranceNumber;
    }

    public void setNationalInsuranceNumber(String nationalInsuranceNumber)
    {
        this.nationalInsuranceNumber = nationalInsuranceNumber;
    }

    public String getSchemeNumber()
    {
        return schemeNumber;
    }

    public void setSchemeNumber(String schemeNumber)
    {
        this.schemeNumber = schemeNumber;
    }

    public byte[] getStringId()
    {
        return stringId;
    }

    public void setStringId(byte[] stringId)
    {
        this.stringId = stringId;
    }

   

    public String getFirstInitial()
    {

        if (!StringUtils.isEmpty(initials))
        {
            char[] initialsChar = initials.toCharArray();
            if (initialsChar.length >= BPAConstants.INT_ONE)
            {
                firstInitial = String.valueOf(initialsChar[0]).toUpperCase(Locale.ENGLISH);

            }

        }
    
        return firstInitial;
    }

   

    public String getSecondInitial()
    {

        if (!StringUtils.isEmpty(initials))
        {
            char[] initialsChar = initials.toCharArray();
            if (initialsChar.length >= BPAConstants.INT_TWO)
            {
                secondInitial = String.valueOf(initialsChar[1]).toUpperCase(Locale.ENGLISH);
            }

        }

        return secondInitial;
    }

 

    public String getThirdInitial()
    {

        if (!StringUtils.isEmpty(initials))
        {
            char[] initialsChar = initials.toCharArray();
            if (initialsChar.length == BPAConstants.INT_THREE)
            {

                thirdInitial = String.valueOf(initialsChar[2]).toUpperCase(Locale.ENGLISH);
            }

        }

        return thirdInitial;
    }

    public void setFirstInitial(String firstInitial)
    {
        this.firstInitial = firstInitial;
    }

    public void setSecondInitial(String secondInitial)
    {
        this.secondInitial = secondInitial;
    }

    public void setThirdInitial(String thirdInitial)
    {
        this.thirdInitial = thirdInitial;
    }

    public String getAutoAuthSpouse()
    {
        return autoAuthSpouse;
    }

    public void setAutoAuthSpouse(String autoAuthSpouse)
    {
        this.autoAuthSpouse = autoAuthSpouse;
    }

    public String getFirstForename()
    {
        return firstForename;
    }

    public void setFirstForename(String firstForename)
    {
        this.firstForename = firstForename;
    }

    public String getSecondForename()
    {
        return secondForename;
    }

    public void setSecondForename(String secondForename)
    {
        this.secondForename = secondForename;
    }

    public String getThirdForename()
    {
        return thirdForename;
    }

    public void setThirdForename(String thirdForename)
    {
        this.thirdForename = thirdForename;
    }

  
}
