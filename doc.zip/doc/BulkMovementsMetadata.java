package com.landg.bpa.services.movements.bulkmovements;

import static com.landg.bpa.batch.metadata.MetadataConstants.START_LAST_CENTURY;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;

import com.landg.bpa.batch.metadata.FileUploadDataType;
import com.landg.bpa.batch.metadata.MetadataComparison;
import com.landg.bpa.batch.metadata.MetadataComparison.MetadataComparisonDateBuilder;
import com.landg.bpa.batch.util.BatchConstants;
import com.landg.bpa.services.iabulkupload.metadata.BulkLoadMetadata;

public enum BulkMovementsMetadata implements BulkLoadMetadata {
   
        EXT_REF_NO("Third Party Reference", FileUploadDataType.TEXT, null, 0, 12, false, null, "externalRefNo",null), 
        EXT_REF_NO_2("Third Party Reference 2",FileUploadDataType.TEXT, null, 0, 12, false, null, "externalRefNo2",null), 
        SURNAME("Surname",FileUploadDataType.TEXT, null, 0,40, false, null, "surname",null),
        FORENAME("Forename",FileUploadDataType.TEXT,null,0,3, false, null, "forename",null),
        INITIALS("Initials",FileUploadDataType.TEXT,null,0,3, false, null, "initials",null),
        SEX("Sex",FileUploadDataType.CVT,"sex",0,1, false, null, "currentSex",null),
        NI_NUMBER("NI Number",FileUploadDataType.TEXT,null,0,9, false, null, "nationalInsuranceNumber",null), 
        DATE_OF_BIRTH("DOB",FileUploadDataType.DATE,null,0,10, false, new MetadataComparisonDateBuilder().addGreaterThanStringDate(START_LAST_CENTURY)
            .addLessThanCurrentDate().build(), "birthDate",null),
        PARENT_EXT_REF_NO("Dependant Third Party Reference", FileUploadDataType.TEXT, null, 0, 12, false, null,"spouseExternalRefNo",
            new String[]{BatchConstants.BULK_MOVEMENTS_TYPE_SUSPENSION,BatchConstants.BULK_MOVEMENTS_TYPE_REINSTATE,
                         BatchConstants.BULK_MOVEMENTS_TYPE_DEATH,BatchConstants.BULK_MOVEMENTS_SPOUSE_SUSPENSION,
                         BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_REINSTATE,BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_DEATH,
                         BatchConstants.BULK_MOVEMENTS_SPOUSE_TRIVCOMM}), 
        PARENT_EXT_REF_NO_2("Dependant Third Party Reference 2", FileUploadDataType.TEXT, null, 0, 12, false, null,"spouseExternalRefNo2",
            new String[]{BatchConstants.BULK_MOVEMENTS_TYPE_SUSPENSION,BatchConstants.BULK_MOVEMENTS_TYPE_REINSTATE,
                         BatchConstants.BULK_MOVEMENTS_TYPE_DEATH,BatchConstants.BULK_MOVEMENTS_SPOUSE_SUSPENSION,
                         BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_REINSTATE,BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_DEATH,
                         BatchConstants.BULK_MOVEMENTS_SPOUSE_TRIVCOMM}), 
        SPOUSE_SEX("Dependant Sex", FileUploadDataType.CVT, "sex", 0, 1, false, null,"spouseSex",
            new String[]{BatchConstants.BULK_MOVEMENTS_TYPE_SUSPENSION,BatchConstants.BULK_MOVEMENTS_TYPE_REINSTATE,
                         BatchConstants.BULK_MOVEMENTS_TYPE_DEATH,BatchConstants.BULK_MOVEMENTS_SPOUSE_SUSPENSION,
                         BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_REINSTATE,BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_DEATH,
                         BatchConstants.BULK_MOVEMENTS_SPOUSE_TRIVCOMM}), 
        SPOUSE_DOB("Dependant DOB", FileUploadDataType.DATE, null, 0, 10, false, new MetadataComparisonDateBuilder<BulkMovementsMetadata>()
            .addGreaterThanStringDate(START_LAST_CENTURY).build(), "spouseDOB",
            new String[]{BatchConstants.BULK_MOVEMENTS_TYPE_SUSPENSION,BatchConstants.BULK_MOVEMENTS_TYPE_REINSTATE,
                         BatchConstants.BULK_MOVEMENTS_TYPE_DEATH,BatchConstants.BULK_MOVEMENTS_SPOUSE_SUSPENSION,
                         BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_REINSTATE,BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_DEATH,
                         BatchConstants.BULK_MOVEMENTS_SPOUSE_TRIVCOMM}), 
        DT_OF_MOVEMENT("Date of Movement", FileUploadDataType.DATE, null, 0, 10, true, null, "dateofMovement",null), 
        MOVEMENT_TYPE("Movement Type", FileUploadDataType.TEXT, null, 0, 40, true, null, "movementType",null), //check the length
        ARRANGE_NAME("Arrangement Name", FileUploadDataType.TEXT, null, 0, 40, false, null, "arrangementName",null),//check the length
        DEPENDANT_TYPE("Dependant Type", FileUploadDataType.CVT, "contingentSpouseType", 0, 25, false, null, "dependantType",
            new String[]{BatchConstants.BULK_MOVEMENTS_TYPE_SUSPENSION,BatchConstants.BULK_MOVEMENTS_TYPE_REINSTATE,
                         BatchConstants.BULK_MOVEMENTS_TYPE_DEATH,BatchConstants.BULK_MOVEMENTS_SPOUSE_SUSPENSION,
                         BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_REINSTATE,BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_DEATH,
                         BatchConstants.BULK_MOVEMENTS_SPOUSE_TRIVCOMM}), 
        FIRST_NAME("Dependant First Name", FileUploadDataType.TEXT, null, 0, 18, false, null, "firstName",null), 
        DEPENDENT_SURNAME("Dependant Surname", FileUploadDataType.TEXT, null, 0, 40, false, null, "dependentSurname",null), 
        MARRIAGE_DATE("Marriage Date", FileUploadDataType.DATE, null, 0, 10, false, null, "marriageDate",
            new String[]{BatchConstants.BULK_MOVEMENTS_TYPE_SUSPENSION,BatchConstants.BULK_MOVEMENTS_TYPE_REINSTATE,
                         BatchConstants.BULK_MOVEMENTS_TYPE_DEATH,BatchConstants.BULK_MOVEMENTS_SPOUSE_SUSPENSION,
                         BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_REINSTATE,BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_DEATH,
                         BatchConstants.BULK_MOVEMENTS_SPOUSE_TRIVCOMM}),
        SCHEME_NUMBER("Scheme number",FileUploadDataType.TEXT, null, 0,40, false, null, "schemeNumber",null),
        AUTO_AUTH_SPOUSE("Auto Authorise Spouse",FileUploadDataType.TEXT,null,0,1, false, null, "autoAuthSpouse",new String[]{BatchConstants.BULK_MOVEMENTS_TYPE_SUSPENSION,BatchConstants.BULK_MOVEMENTS_TYPE_REINSTATE,
            BatchConstants.BULK_MOVEMENTS_TYPE_DEATH,BatchConstants.BULK_MOVEMENTS_SPOUSE_SUSPENSION,
            BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_REINSTATE,BatchConstants.BULK_MOVEMENTS_TYPE_SPOUSE_DEATH,
            BatchConstants.BULK_MOVEMENTS_SPOUSE_TRIVCOMM});

    private String nameInFile;
    private FileUploadDataType type;
    private String subType; // eg cvt table name
    /*These are the max/min allowed lengths in the file not the database*/
    private Integer minLength;
    private Integer maxLength;
    private Boolean mandatory;
    private MetadataComparison ranges;
    private String javaFieldName;   
    private String[] passiveFieldCheck;// this array holds the movement types for which this field should not be populated

    //private Boolean updateable; // not needed in box 4.1 perhaps in the future

    BulkMovementsMetadata(
        String name,
        FileUploadDataType type,
        String subType,
        Integer min,
        Integer max,
        Boolean mandatory,
        MetadataComparison ranges,
        String javaFieldName,String[] passiveFieldCheck)
    {
        this.nameInFile = name;
        this.type = type;
        this.minLength = min;
        this.maxLength = max;
        this.mandatory = mandatory;
        this.subType = subType;
        this.ranges = ranges;
        this.javaFieldName = javaFieldName;
        if(null!=passiveFieldCheck)
        {
        this.passiveFieldCheck =passiveFieldCheck.clone();
        }
    }

    public String getSubType()
    {
        return subType;
    }

    public void setSubType(String subType)
    {
        this.subType = subType;
    }

    public Integer getMinLength()
    {
        return minLength;
    }

    public void setMinLength(Integer minLength)
    {
        this.minLength = minLength;
    }

    public Integer getMaxLength()
    {
        return maxLength;
    }

    public void setMaxLength(Integer maxLength)
    {
        this.maxLength = maxLength;
    }

    public Boolean getMandatory()
    {
        return mandatory;
    }

    public void setMandatory(Boolean mandatory)
    {
        this.mandatory = mandatory;
    }

    public MetadataComparison getRanges()
    {
        return ranges;
    }

    public void setRanges(MetadataComparison ranges)
    {
        this.ranges = ranges;
    }

    public void setNameInFile(String nameInFile)
    {
        this.nameInFile = nameInFile;
    }

    public void setType(FileUploadDataType type)
    {
        this.type = type;
    }

    public void setJavaFieldName(String javaFieldName)
    {
        this.javaFieldName = javaFieldName;
    }

    public String getNameInFile()
    {
        return nameInFile;
    }

    public FileUploadDataType getType()
    {
        return type;
    }

    public String getJavaFieldName()
    {
        return javaFieldName;
    }

    @Override
    public List<String> getAllFileNames()
    {
        List<String> names = new ArrayList<String>();
        for (BulkMovementsMetadata data : BulkMovementsMetadata.values())
        {
            names.add(data.getNameInFile());
        }
        return names;
    }

    @Override
    public List<String> getMandatoryFileNames()
    {
        List<String> names = new ArrayList<String>();
        for (BulkMovementsMetadata data : BulkMovementsMetadata.values())
        {
            if (data.getMandatory())
            {
                names.add(data.getNameInFile());
            }
        }
        return names;
    }

    @Override
    public String getValueStringForFileNameString(String fileName)
    {
        // TODO Auto-generated method stub
        if (fileName == null)
        {
            return null;
        }

        for (BulkMovementsMetadata data : BulkMovementsMetadata.values())
        {
            if (fileName.equals(data.getNameInFile()))
            {
                return data.name();
            }
        }
        return null;
    }

    public String[] getPassiveFieldCheck()
    {
        return ArrayUtils.clone(passiveFieldCheck);
    }

    public void setPassiveFieldCheck(String[] passiveFieldCheck)
    {
        this.passiveFieldCheck = ArrayUtils.clone(passiveFieldCheck);
    }

}
